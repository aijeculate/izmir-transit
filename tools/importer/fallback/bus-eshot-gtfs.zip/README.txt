Stop order per ESHOT line direction, taken from the official GTFS feed (bus-eshot-gtfs.zip, service 2026-08-05..2026-10-09) as imported for v1.2.0.
Used only when the live feed cannot be downloaded (it times out from GitHub Actions). Only routes, trips, stop_times and calendar are kept.
